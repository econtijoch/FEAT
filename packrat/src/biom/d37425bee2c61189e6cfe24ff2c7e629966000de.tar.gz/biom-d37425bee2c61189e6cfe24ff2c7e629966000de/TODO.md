<link href="http://joey711.github.com/phyloseq/markdown.css" rel="stylesheet"></link>

The biom package is under active development. 

Planned feature improvements are publicly catalogued on github; specifically on the [issues tracker for the biom R package](https://github.com/joey711/biom/issues), and the [issues tracker for the biom-format itself](https://github.com/biom-format/biom-format/issues).

If the feature you are hoping for is not listed, you are welcome to add it as a feature request "issue" on this page. This request will be publicly available and listed on the page.


